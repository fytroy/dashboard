import streamlit as st
import datetime
import requests
import zipfile
import os
from datetime import datetime as dt_object
import time # For simulating delays
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
import google.generativeai as genai
import PyPDF2
from io import BytesIO

# --- Configuration ---
# API keys are now loaded from Streamlit secrets
try:
    WEATHER_API_KEY = st.secrets["OPENWEATHERMAP_API_KEY"]
    NEWS_API_KEY = st.secrets["NEWS_API_KEY"]
    GEMINI_API_KEY = st.secrets["GEMINI_API_KEY"]
    GMAIL_USER = st.secrets["GMAIL_USER"]
    GMAIL_APP_PASSWORD = st.secrets["GMAIL_APP_PASSWORD"]
except KeyError as e:
    st.error(f"Missing API key or credential in .streamlit/secrets.toml: {e}. Please refer to the setup instructions.")
    st.stop() # Stop the app if essential secrets are missing

# Configure Google Gemini API
genai.configure(api_key=GEMINI_API_KEY)
model = genai.GenerativeModel('gemini-pro')

# --- Streamlit Page Setup ---
st.set_page_config(
    page_title="Personal Automation Dashboard",
    layout="centered",
    initial_sidebar_state="expanded"
)

st.title("🛠️ Personal Automation Dashboard")
st.markdown("---")

# --- Function Definitions for Modules ---

# 1. Crypto Price Watch
def get_btc_price():
    try:
        r = requests.get("https://api.coindesk.com/v1/bpi/currentprice/BTC.json")
        r.raise_for_status() # Raise an HTTPError for bad responses (4xx or 5xx)
        return float(r.json()["bpi"]["USD"]["rate_float"])
    except requests.exceptions.RequestException as e:
        st.error(f"Error fetching Bitcoin price: {e}")
        return None

def get_eth_price():
    try:
        # CoinGecko API for Ethereum
        r = requests.get("https://api.coingecko.com/api/v3/simple/price?ids=ethereum&vs_currencies=usd")
        r.raise_for_status()
        data = r.json()
        if "ethereum" in data and "usd" in data["ethereum"]:
            return float(data["ethereum"]["usd"])
        else:
            st.warning("Could not parse Ethereum price from API response.")
            return None
    except requests.exceptions.RequestException as e:
        st.error(f"Error fetching Ethereum price: {e}")
        return None

# 2. File Backup
def backup_folder(folder_path=".", output_dir="."):
    """
    Compresses the specified folder into a zip file in the output_dir.
    Defaults to current directory for both if no args are given.
    """
    if not os.path.exists(folder_path):
        return f"Error: Folder '{folder_path}' does not exist."

    if not os.path.exists(output_dir):
        os.makedirs(output_dir)

    now = dt_object.now().strftime("%Y%m%d_%H%M%S")
    base_folder_name = os.path.basename(os.path.abspath(folder_path)) # Get base name for zip
    zipname = os.path.join(output_dir, f"backup_{base_folder_name}_{now}.zip")
    try:
        with zipfile.ZipFile(zipname, "w", zipfile.ZIP_DEFLATED) as z:
            for root, _, files in os.walk(folder_path):
                for file in files:
                    file_path = os.path.join(root, file)
                    # Arcname is the path inside the zip file
                    arcname = os.path.relpath(file_path, folder_path)
                    z.write(file_path, arcname)
        return f"Files backed up to: `{zipname}`"
    except Exception as e:
        return f"Error during backup: {e}"

# 3. Weather Fetcher
def get_weather(city="London"):
    if not WEATHER_API_KEY or WEATHER_API_KEY == 'YOUR_OPENWEATHERMAP_API_KEY': # Check against placeholder too
        return "Please set your OpenWeatherMap API key in .streamlit/secrets.toml."
    url = f"http://api.openweathermap.org/data/2.5/weather?q={city}&appid={WEATHER_API_KEY}&units=metric"
    try:
        data = requests.get(url).json()
        if data.get("cod") == 200:
            temp = data["main"]["temp"]
            description = data["weather"][0]["description"]
            return f"{temp}°C, {description.capitalize()}"
        else:
            return f"Error fetching weather: {data.get('message', 'Unknown error')}"
    except requests.exceptions.RequestException as e:
        return f"Network error fetching weather: {e}"
    except KeyError:
        return "Error parsing weather data. Check city name or API response."

# 4. News Summary (Using NewsAPI.org and Gemini for summarization)
def get_news_summary(query="general", language="en", num_articles=3):
    if not NEWS_API_KEY or NEWS_API_KEY == 'YOUR_NEWSAPI_ORG_API_KEY':
        return "Please set your NewsAPI.org API key in .streamlit/secrets.toml."
    if not GEMINI_API_KEY or GEMINI_API_KEY == 'YOUR_GOOGLE_GEMINI_API_KEY':
        return "Please set your Google Gemini API key in .streamlit/secrets.toml for summarization."

    url = f"https://newsapi.org/v2/top-headlines?q={query}&language={language}&apiKey={NEWS_API_KEY}"
    try:
        response = requests.get(url)
        response.raise_for_status()
        data = response.json()
        articles = data.get("articles", [])

        if not articles:
            return f"No news found for '{query}'."

        summary_parts = []
        for i, article in enumerate(articles[:num_articles]):
            title = article.get("title", "No Title")
            description = article.get("description", "No Description")
            content = article.get("content", "") # NewsAPI often truncates content
            article_url = article.get("url", "#")

            text_to_summarize = f"Title: {title}\nDescription: {description}\nContent: {content}"
            try:
                # Use Gemini to summarize each article
                response = model.generate_content(f"Summarize the following news article briefly (1-2 sentences): {text_to_summarize}")
                summary_text = response.text.strip()
            except Exception as e:
                summary_text = f"Could not summarize article (LLM Error: {e})"

            summary_parts.append(f"**{i+1}. [{title}]({article_url})**\n   - {summary_text}")

        return "### Top News Headlines:\n" + "\n\n".join(summary_parts)

    except requests.exceptions.RequestException as e:
        return f"Error fetching news: {e}"
    except Exception as e:
        return f"An unexpected error occurred during news processing: {e}"


# 5. Website Checker
def check_website_uptime(url):
    try:
        response = requests.get(url, timeout=5) # 5-second timeout
        if response.status_code == 200:
            return f"🟢 {url} is UP (Status: {response.status_code})"
        else:
            return f"🟠 {url} is DOWN (Status: {response.status_code})"
    except requests.exceptions.RequestException as e:
        return f"🔴 {url} is DOWN (Error: {e})"

# 6. PDF/Note Scanner (Reads PDF and uses LLM for summarization)
def summarize_pdf_content(uploaded_file):
    if not GEMINI_API_KEY or GEMINI_API_KEY == 'YOUR_GOOGLE_GEMINI_API_KEY':
        return "Please set your Google Gemini API key in .streamlit/secrets.toml for summarization."

    if uploaded_file is None:
        return "Please upload a PDF file to summarize."

    try:
        # Read PDF content
        pdf_reader = PyPDF2.PdfReader(uploaded_file)
        text_content = ""
        for page_num in range(len(pdf_reader.pages)):
            page = pdf_reader.pages[page_num]
            text_content += page.extract_text()

        if not text_content.strip():
            return "Could not extract text from the PDF. It might be an image-based PDF or empty."

        # Limit text content to avoid exceeding LLM token limits (adjust as needed)
        MAX_TEXT_LENGTH = 10000 # Approximately 10k characters, adjust based on model limits
        if len(text_content) > MAX_TEXT_LENGTH:
            st.warning(f"PDF content is very large ({len(text_content)} chars). Truncating for summarization.")
            text_content = text_content[:MAX_TEXT_LENGTH] + "..."

        st.info("Sending content to Gemini for summarization. This may take a moment...")
        # Use Gemini to summarize the extracted text
        response = model.generate_content(f"Summarize the following document content:\n\n{text_content}")
        summary = response.text.strip()

        return f"**Summary of '{uploaded_file.name}':**\n\n{summary}"

    except PyPDF2.utils.PdfReadError:
        return "Error reading PDF file. It might be corrupted or not a valid PDF."
    except Exception as e:
        return f"An unexpected error occurred during PDF summarization: {e}"


# 7. Scheduler (Mocked/Triggered)
def run_scheduled_task(task_name):
    # In a real scenario, `schedule` or `APScheduler` would run in the background
    # This just simulates immediate execution
    st.info(f"Running scheduled task: '{task_name}' now...")
    time.sleep(1) # Simulate task execution
    return f"Task '{task_name}' executed successfully."

# 8. Send Quick Email
def send_email(to_email, subject, message_body):
    if not GMAIL_USER or not GMAIL_APP_PASSWORD:
        return "Please set your GMAIL_USER and GMAIL_APP_PASSWORD in .streamlit/secrets.toml for email sending."

    msg = MIMEMultipart()
    msg['From'] = GMAIL_USER
    msg['To'] = to_email
    msg['Subject'] = subject
    msg.attach(MIMEText(message_body, 'plain'))

    try:
        with smtplib.SMTP_SSL('smtp.gmail.com', 465) as smtp:
            smtp.login(GMAIL_USER, GMAIL_APP_PASSWORD)
            smtp.send_message(msg)
        return "Email sent successfully!"
    except Exception as e:
        return f"Error sending email: {e}. Please check your Gmail credentials and 'App passwords' settings if using 2FA."


# --- Dashboard Layout ---

# Initialize session state variables if they don't exist
if 'btc_price' not in st.session_state:
    st.session_state['btc_price'] = "N/A"
if 'eth_price' not in st.session_state:
    st.session_state['eth_price'] = "N/A"
if 'weather_report' not in st.session_state:
    st.session_state['weather_report'] = "No weather fetched yet."
if 'website_status' not in st.session_state:
    st.session_state['website_status'] = "No website checked yet."

# Sidebar for common actions or configurations
with st.sidebar:
    st.header("⚙️ Settings & Quick Actions")
    st.markdown("---")

    st.subheader("Crypto Price Refresh")
    if st.button("🔄 Refresh Crypto Prices"):
        with st.spinner("Fetching crypto prices..."):
            btc_price = get_btc_price()
            eth_price = get_eth_price()
            if btc_price:
                st.session_state['btc_price'] = f"${btc_price:,.2f}"
            if eth_price:
                st.session_state['eth_price'] = f"${eth_price:,.2f}"
        st.success("Prices updated!")

    st.subheader("Weather Location")
    weather_city_input = st.text_input("Enter City for Weather:", value="Nairobi")
    if st.button("☁️ Get Weather"):
        with st.spinner("Fetching weather..."):
            weather_report = get_weather(weather_city_input)
        st.session_state['weather_report'] = weather_report
        st.success("Weather updated!")

    st.subheader("Website Monitor")
    website_url = st.text_input("Website URL to Check:", value="https://www.google.com")
    if st.button("🌐 Check Website"):
        with st.spinner("Checking website..."):
            website_status = check_website_uptime(website_url)
        st.session_state['website_status'] = website_status
        st.success("Website status updated!")

    st.markdown("---")
    st.markdown("For a real scheduler, consider a separate script running with `schedule` or `APScheduler`.")


# Main Content Area
st.header("⚡ Modules")
col1, col2 = st.columns(2)

with col1:
    st.subheader("📁 File Backup")
    backup_source_folder = st.text_input("Folder to Backup (e.g., '.' for current, 'my_documents'):", value=".")
    backup_output_folder = st.text_input("Backup Destination (e.g., 'backups'):", value="backups")
    if st.button("▶️ Start Backup"):
        with st.spinner(f"Backing up '{backup_source_folder}'..."):
            backup_result = backup_folder(backup_source_folder, backup_output_folder)
        st.info(backup_result)

    st.subheader("📧 Send Quick Email")
    email_to = st.text_input("Recipient Email:", key="email_to_input")
    email_subject = st.text_input("Subject:", key="email_subject_input")
    email_message = st.text_area("Message:", key="email_message_input")
    if st.button("🚀 Send Email"):
        if email_to and email_message:
            with st.spinner("Sending email..."):
                email_status = send_email(email_to, email_subject, email_message)
            st.success(email_status)
        else:
            st.warning("Please fill in recipient and message for the email.")

with col2:
    st.subheader("🗞️ News Summary")
    news_query = st.text_input("News Topic (e.g., 'technology', 'finance'):", value="AI")
    if st.button("📰 Fetch & Summarize News"):
        with st.spinner(f"Fetching and summarizing news about '{news_query}'..."):
            news_summary = get_news_summary(query=news_query)
        st.markdown(f"```markdown\n{news_summary}\n```")

    st.subheader("📝 PDF/Note Summarizer")
    uploaded_file = st.file_uploader("Upload a PDF file", type="pdf")
    if st.button("🧠 Summarize Document"):
        if uploaded_file is not None:
            with st.spinner("Summarizing document..."):
                summary_output = summarize_pdf_content(uploaded_file)
            st.info(summary_output)
        else:
            st.warning("Please upload a PDF file first.")

    st.subheader("🕒 Task Scheduler (Trigger Now)")
    task_name_input = st.text_input("Task to Trigger (e.g., 'Daily Report Generation'):")
    if st.button("⚡ Trigger Task"):
        if task_name_input:
            st.info(run_scheduled_task(task_name_input))
        else:
            st.warning("Please enter a task name to trigger.")

st.markdown("---")
st.subheader("Current Status & Outputs")

# Display outputs from sidebar actions
st.metric(label="Bitcoin Price (USD)", value=st.session_state['btc_price'])
st.metric(label="Ethereum Price (USD)", value=st.session_state['eth_price'])
st.info(f"**Weather:** {st.session_state['weather_report']}")
st.info(f"**Website Status:** {st.session_state['website_status']}")


st.markdown("---")
st.markdown(f"Last updated: {dt_object.now().strftime('%Y-%m-%d %H:%M:%S')}")